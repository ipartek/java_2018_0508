# HTML5-APIs
Imaginación, conocer su aplicación. HTML5 es la piedra angular de la plataforma web abierta de la W3C, un marco diseñado para apoyar la innovación y fomentar el potencial de la web tiene para ofrecer. Anunciando esta colección revolucionaria de herramientas y normas, el sistema de identidad de HTML5 provee el vocabulario visual para clasificar y comunicar claramente nuestros esfuerzos colectivos.

![Alt text](https://github.com/anderuraga/HTML5-APIs/blob/master/screenshot.png)
