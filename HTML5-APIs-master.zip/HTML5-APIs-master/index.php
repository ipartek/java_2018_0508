<?php 

	//  APIs/index.php 
    //  basado en: http://www.w3.org/html/logo/#the-technology
?>

<!DOCTYPE html>
<html>
<head>

	<title>APIs HTML5</title>
	<link rel="stylesheet" type="text/css" charset="UTF-8" href="css/html5.css">   
	<meta charset="utf-8">

	<script src="js/jquery-1.4.4.min.js"></script>
	<script src="js/rotar-imagenes-home.js"></script>
</head>
<body>

<header>
	<a href="#" id="inicio">
		<img src="images/html5-badge-h-connectivity-css3-device-graphics-multimedia-performance-semantics-storage.png" width="357" height="64" alt="HTML5 Powered with Connectivity / Realtime, CSS3 / Styling, Device Access, Graphics, 3D &amp; Effects, Multimedia, Performance &amp; Integration, Semantics, and Offline &amp; Storage" title="HTML5 Powered with Connectivity / Realtime, CSS3 / Styling, Device Access, Graphics, 3D &amp; Effects, Multimedia, Performance &amp; Integration, Semantics, and Offline &amp; Storage">
	</a>
	<h1>
		HTML5 + CSS3
	</h1>
</header>

<section id="the-technology">
      <div id="the-technology-top">
        <div id="the-current-class">
          <img width="495" height="370" title="Semantics" alt="Semantics" id="semantics-header" src="images/class-header-semantics.jpg">
          <img width="495" height="370" title="Offline &amp; Storage" alt="Offline &amp; Storage" id="offline-storage-header" src="images/class-header-offline.jpg" style="display: none;">
          <img width="495" height="370" title="Device Access" alt="Device Access" id="device-access-header" src="images/class-header-device.jpg" style="display: none;">
          <img width="495" height="370" title="Connectivity" alt="Connectivity" id="connectivity-header" src="images/class-header-connectivity.jpg" style="display: none;">
          <img width="495" height="370" title="Multimedia" alt="Multimedias" id="multimedia-header" src="images/class-header-multimedia.jpg" style="display: none;">
          <img width="495" height="370" title="3D &amp; Effects" alt="3D &amp; Effects" id="threed-effects-header" src="images/class-header-3d.jpg" style="display: none;">
          <img width="495" height="370" title="Performance &amp; Integration" alt="Performance &amp; Integration" id="performance-integration-header" src="images/class-header-performance.jpg" style="display: none;">
          <img width="495" height="370" title="CSS3 &amp; Styling" alt="CSS3 &amp; Styling" id="css3-styling-header" src="images/class-header-css3.jpg" style="display: none;">
        </div>
        <div id="the-technology-overview">
          <h2>La Tecnologia</h2>
          <p>
            Imaginación, conocer su aplicación. HTML5 es la piedra angular de la plataforma web abierta de la W3C,
           un marco diseñado para apoyar la innovación y fomentar el potencial de la web tiene para ofrecer.
           Anunciando esta colección revolucionaria de herramientas y normas, el sistema de identidad de HTML5 
           provee el vocabulario visual para clasificar y comunicar claramente nuestros esfuerzos colectivos.
          </p>
        </div>
    </div>
    <div id="the-technology-bottom">
     
      <div id="the-classes">
      
        <ul>
          <li><a title="Semantics" id="semantics-icon" class="active" href="#semantics-desc"><span></span></a></li>
          <li><a title="Offline &amp; Storage" id="offline-storage-icon" href="#offline-storage-desc"><span></span></a></li>
          <li><a title="Device Access" id="device-access-icon" href="#device-access-desc"><span></span></a></li>
          <li class="class-end"><a title="Connectivity" id="connectivity-icon" href="#connectivity-desc"><span></span></a></li>
          <li><a title="Multimedia" id="multimedia-icon" href="#multimedia-desc"><span></span></a></li>
          <li><a title="3D &amp; Effects" id="threed-effects-icon" href="#threed-effects-desc"><span></span></a></li>
          <li><a title="Performance &amp; Integration" id="performance-integration-icon" href="#performance-integration-desc"><span></span></a></li>
          <li class="class-end"><a title="CSS3 &amp; Styling" id="css3-styling-icon" href="#css3-styling-desc"><span></span></a></li>
        </ul>
      </div>
      <div class="class-description">
          <div id="semantics-desc">
            <div class="class-number-icon">~ 1 of 8 ~ </div>
            <h2>Class: Semantics</h2>
            
            <p>
              Dar sentido a la estructura, la semántica es nodal con HTML5. 
              Un <b>conjunto más amplio de TAGs</b> aportando nuevos valores, junto con RDFa, microdatos y microformatos , 
              están permitiendo una mayor utilidad impulsando la web para programadores y usuarios.
            </p>
          </div>
          <div style="display: none;" id="offline-storage-desc">
            <div class="class-number-icon">~ 2 of 8 ~</div>
            <h2>Class: Offline &amp; Storage</h2>
            
            <p>
              Web Apps pueden empezar más rápido y trabajar incluso si no hay conexión a Internet,
               gracias al HTML5 <b>Aplication Cache</b>, así como el almacenamiento local <b> Web Storage</b>, 
              <b>Web SQL Storage</b>, <b>indexedDB</b>, y las especificaciones de la API de archivos.
            </p>
          </div>
          <div style="display: none;" id="device-access-desc">
            <div class="class-number-icon">~ 3 of 8 ~ </div>
            <h2>Class: Device Access</h2>
            
            <p>
              A partir de la API de <b>geolocalización</b>, aplicaciones Web pueden presentar ricas características
               y experiencias dispositivo con conciencia. Innovaciones acceso increíble dispositivo se están desarrollando
                y aplicando, desde el acceso de <b>audio / vídeo</b> de entrada a los <b>micrófonos</b> y las <b>cámaras</b>,
                 a los <b>datos locales</b>, como <b>contactos</b> y <b>eventos</b>, y la <b>orientación incluso inclinación</b>. 
            </p>
          </div>
          <div style="display: none;" id="connectivity-desc">
            <div class="class-number-icon">~ 4 of 8 ~ </div>
            <h2>Class: Connectivity</h2>
            
            <p>
              Conectividad más eficiente significa más chats en tiempo real, 
              juegos más rápidos, y una mejor comunicación. 
              <b>Web Sockets</b> y de servidor enviados eventos están presionando (nunca mejor dicho)
               de datos entre el cliente y el servidor de manera más eficiente que nunca.
            </p>
          </div>
          <div style="display: none;" id="multimedia-desc">
            <div class="class-number-icon">~ 5 of 8 ~</div>
            <h2>Class: Multimedia</h2>
            
            <p>
              Audio y video son ciudadanos de primera clase en la web HTML5, 
              que viven en armonía con sus aplicaciones y sitios. Luces, cámara, acción!
           </p>
          </div>
          <div style="display: none;" id="threed-effects-desc">
            <div class="class-number-icon">~ 6 of 8 ~</div>
            <h2>Class: 3D, Graphics &amp; Effects</h2>
            
            <p>
              Entre <b>SVG</b>, <b>Canvas</b>, <b>WebGL</b> y <b>CSS3 3D</b>, que te van a sorprender 
              a sus usuarios con impresionantes efectos visuales de forma nativa prestados en el navegador.
            </p>
          </div>
          <div style="display: none;" id="performance-integration-desc">
            <div class="class-number-icon">~ 7 of 8 ~ </div>
            <h2>Class: Performance &amp; Integration</h2>
            
            <p>
              Haga que sus aplicaciones Web y contenido Web dinámico más rápido con una variedad de técnicas y 
              tecnologías como <b>Web Workers</b> y XMLHttpRequest 2. 
              Ningún usuario volvera a mirar su reloj mientras espera.
            </p>
          </div>
          <div style="display: none;" id="css3-styling-desc">
            <div class="class-number-icon">~ 8 of 8 ~ </div>
            <h2>Class: CSS3</h2>
            
            <p>
              CSS3 ofrece una amplia gama de estilización y los efectos,
              la mejora de la aplicación web sin sacrificar su estructura o funcionamiento semántico.
              Además Web Open Font Format (WOFF) proporciona flexibilidad 
              y control tipográfico más allá de lo que la web ha ofrecido antes.
            </p>
          </div>
        </div>
      </div>
    </section>


</body>
</html>    